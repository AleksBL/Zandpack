from pickle import load
from params import name, eps,dH, bias, t0, t1
import os
from TimedependentTransport.TimedependentTransport import AdaptiveRK4 as RK4
import os
import numpy as np
import matplotlib.pyplot as plt

C = load(open(name+'.Timedep', 'rb'))
RHS = C.make_f_purenp()
files = os.listdir()
is_rerun = (name + '_last_sig.npy' in files)
Complete = ('Complete.txt' in files)
if Complete:
    is_rerun = 'Complete'

print('Rerun: ',is_rerun)

def has_numbers(inputString):
    return any(char.isdigit() for char in inputString)

def write_complete():
    with open('Complete.txt','w') as f:
        f.write('Calculation Done')
    f.close()

if is_rerun == False:
    run_number = np.array([0])
    np.save('run_number', run_number)
    sig        = C.sigma
    psi        = C.Psi_vec
    omega      = C.omegas
    
    t, d  = RK4( RHS, 
                   sig, psi, omega, 
                   eps, 
                   t0, t1,
                   dH, 
                   bias, C.Ixi, 0.01, fixed_mode = False, 
                   name = name)
    
    write_complete()

elif is_rerun == True:
    run_number = int(np.load('run_number.npy'))
    cf = [f for f in os.listdir() if 'current' in f and has_numbers(f) == False]
    
    os.system('mv ' + '_times.npy _times'+str(run_number) + '.npy')
    for f in cf:
        os.system('mv '+ f + ' '+str(run_number)+f)
    
    run_number+=1
    np.save('run_number', np.array(run_number))
    
    t, d  = RK4(   RHS, 
                   None, None, None, 
                   eps, 
                   None, t1,
                   dH, 
                   bias, C.Ixi, 0.01, fixed_mode = False, 
                   name = name)
    
    write_complete()

elif is_rerun == 'Complete':
    cf          = [f for f in os.listdir() if 'current' in f and has_numbers(f) == True ]
    cf_u        = [f for f in os.listdir() if 'current' in f and has_numbers(f) == False]
    times_files = [f for f in os.listdir() if 'times' in f and   has_numbers(f) == True ]
    t           = np.hstack([np.load(tf) for tf in sorted(times_files)])
    currents = []
    for c in cf_u:
        ff = [f for f in cf if c in f]
        ff = sorted(ff)
        J = np.vstack([np.load(FF) for FF in ff])
        J = np.vstack((J, np.load(c)))
        currents += [J]
    t = np.hstack((t,np.load('_times.npy')))
    for c in currents:
        plt.plot(t, c)
