import numpy as np

name = 'Chain'
eps  = 1e-5
t0, t1 = -100, 100

def bias(t,a):
    if a == 0:
        return np.exp(-t**2 / 20**2)
    else:
        return -np.exp(-t**2 / 20**2)

def dH(t,sigma):
    return np.zeros(sigma.shape, dtype = np.complex128)

