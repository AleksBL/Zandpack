from params import name
import numpy as np
import matplotlib.pyplot as plt
import sisl
from TimedependentTransport.TimedependentTransport import TD_Transport as TDT

tx = 5
t_dev  =  -2.7
t_elec =  -2.7

lat_const = 2.5
line = np.linspace(-5 , 5, 51)  + 1j*1e-2
line = np.vstack((line,line))

geom_dev   = sisl.geom.sc(lat_const, 'H').tile(tx+2, 0)
geom_ep    = sisl.geom.sc(lat_const, 'H').tile(1, 0).move(np.array([lat_const * (tx+1), 0, 0]))
geom_em    = sisl.geom.sc(lat_const, 'H').tile(1, 0)

geom_dev   = geom_dev.add_vacuum(10,1).add_vacuum(10,2).add_vacuum(10,0)
geom_em    = geom_em. add_vacuum(10,1).add_vacuum(10,2)
geom_ep    = geom_ep. add_vacuum(10,1).add_vacuum(10,2)

C = TDT([geom_em,geom_ep], geom_dev, kT_i = [0.025, 0.025])
C.Make_Contour(line, 20 ,pole_mode = 'JieHu2011')
plt.show()

C.Electrodes( semi_infs = ['-a1', '+a1'] )
C.make_device(
            elec_inds = [[0],[tx+1]]
            )

elec = sisl.Hamiltonian(sisl.geom.sc(lat_const, sisl.Atom(1, R= 3.0)).add_vacuum(10,1).add_vacuum(10,2))
elec.construct([[0.1, lat_const * 1.1], 
                [0  , t_elec             ]])

C.run_electrodes(
                    fois_gras_H = [elec, elec]
                  )

dev_H = sisl.Hamiltonian(sisl.geom.sc(lat_const, sisl.Atom(1, R= 3.0)).tile(tx+2,0).add_vacuum(10,1).add_vacuum(10,2).add_vacuum(10,0))
dev_H.construct([[0.1, lat_const * 1.1], 
                  [0,   1              ] ])


dev_H[0,1]      =  5**0.5
dev_H[1,0]      =  5**0.5
dev_H[tx+1,tx]  =  5**0.5
dev_H[tx,tx+1]  =  5**0.5

C.run_device(fois_gras_H = dev_H)
C.read_data()

def run_mini(its):
    C.Fit(fact = 2.0, Fallback_W = 30.0, NumL = 8, fit_mode = 'all_from_SE', 
              use_analytical_jac = True,  min_method = 'SLSQP',
              ebounds = (-10, 10), 
              wbounds = (0.1, 10.0), 
              gbounds = (None, None),
              tol = -1.0, options = {'disp':True,'maxiter':its, 'gtol':1e-5, 'iprint':1}, 
              fit_real_part = False,
              specific_bounds = None, 
              alpha_PO = 0.0)

run_mini(1000)
C.diagonalise()
C.get_propagation_quantities()
C.get_dense_matrices_purenp()
C.Check_input_to_ODE(loose_fermi = True)

C.pickle(name)


