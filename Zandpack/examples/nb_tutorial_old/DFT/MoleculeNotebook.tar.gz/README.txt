Older example that might not be up to date.
